package types;

public class ConstructorTypes {

    // Default constructor
    public ConstructorTypes() {
        System.out.println("Default constructor called");
    }

    // Parameterized constructor
    public ConstructorTypes(String message) {
        System.out.println("Parameterized constructor called with message: " + message);
    }

    // Overloaded constructor
    public ConstructorTypes(int value) {
        System.out.println("Overloaded constructor called with value: " + value);
    }

    public static void main(String[] args) {
        // Creating objects using different constructors
        ConstructorTypes defaultConstructorObj = new ConstructorTypes();
        ConstructorTypes parameterizedConstructorObj1 = new ConstructorTypes("Hello, world!");
        ConstructorTypes parameterizedConstructorObj2 = new ConstructorTypes(42);
    }
}
