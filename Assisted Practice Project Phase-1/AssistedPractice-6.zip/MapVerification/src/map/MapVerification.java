package map;

import java.util.HashMap;
import java.util.TreeMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Iterator;

public class MapVerification {

    public static void main(String[] args) {
        
        Map<String, Integer> hashMap = new HashMap<>();

       
        hashMap.put("One", 1);
        hashMap.put("Three", 3);
        hashMap.put("Two", 2);

        System.out.println("HashMap Elements:");
        printMap(hashMap);

        Map<String, Integer> treeMap = new TreeMap<>();

       
        treeMap.put("Banana", 2);
        treeMap.put("Apple", 1);
        treeMap.put("Cherry", 3);

        System.out.println("\nTreeMap Elements:");
        printMap(treeMap);

        Map<String, Integer> linkedHashMap = new LinkedHashMap<>();

        linkedHashMap.put("Zebra", 26);
        linkedHashMap.put("Lion", 12);
        linkedHashMap.put("Tiger", 19);

        System.out.println("\nLinkedHashMap Elements:");
        printMap(linkedHashMap);
    }

    private static void printMap(Map<String, Integer> map) {
        Iterator<Map.Entry<String, Integer>> iterator = map.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, Integer> entry = iterator.next();
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}
