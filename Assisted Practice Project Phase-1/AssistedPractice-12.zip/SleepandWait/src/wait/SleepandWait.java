package wait;

public class SleepandWait {

    public static void main(String[] args) {
        final Object lock = new Object();

        // Thread using sleep
        Thread sleepThread = new Thread(() -> {
            System.out.println("SleepThread: Started");
            try {
                Thread.sleep(2000); // Sleep for 2 seconds
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("SleepThread: Finished");
        });

        // Thread using wait and notify
        Thread waitThread = new Thread(() -> {
            System.out.println("WaitThread: Started");
            synchronized (lock) {
                try {
                    lock.wait(); // Wait for notification
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println("WaitThread: Resumed");
        });

        sleepThread.start();
        waitThread.start();

        try {
            Thread.sleep(1000); // Sleep for 1 second to ensure waitThread starts first
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Notify the waitThread to resume
        synchronized (lock) {
            lock.notify();
        }
    }
}
