package matrix;

import java.util.Scanner;

public class MatrixMultiplication {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the number of rows for the first matrix: ");
        int rowsA = input.nextInt();
        System.out.print("Enter the number of columns for the first matrix: ");
        int colsA = input.nextInt();

        System.out.print("Enter the number of rows for the second matrix: ");
        int rowsB = input.nextInt();
        System.out.print("Enter the number of columns for the second matrix: ");
        int colsB = input.nextInt();

        if (colsA != rowsB) {
            System.out.println("Matrix multiplication is not possible. Number of columns in the first matrix must be equal to the number of rows in the second matrix.");
        } else {
            int[][] matrixA = new int[rowsA][colsA];
            int[][] matrixB = new int[rowsB][colsB];
            int[][] resultMatrix = new int[rowsA][colsB];

            System.out.println("Enter elements of the first matrix:");
            for (int i = 0; i < rowsA; i++) {
                for (int j = 0; j < colsA; j++) {
                    matrixA[i][j] = input.nextInt();
                }
            }

            System.out.println("Enter elements of the second matrix:");
            for (int i = 0; i < rowsB; i++) {
                for (int j = 0; j < colsB; j++) {
                    matrixB[i][j] = input.nextInt();
                }
            }

            // Perform matrix multiplication
            for (int i = 0; i < rowsA; i++) {
                for (int j = 0; j < colsB; j++) {
                    for (int k = 0; k < colsA; k++) {
                        resultMatrix[i][j] += matrixA[i][k] * matrixB[k][j];
                    }
                }
            }

            // Display the result
            System.out.println("Result of matrix multiplication:");
            for (int i = 0; i < rowsA; i++) {
                for (int j = 0; j < colsB; j++) {
                    System.out.print(resultMatrix[i][j] + " ");
                }
                System.out.println();
            }
        }

        input.close();
    }
}
