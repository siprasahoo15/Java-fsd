package modifiers;

//Create a class with various access modifiers
public class AccessModifiers {

 // Public field accessible from anywhere
 public int publicField = 10;

 // Protected field accessible within the package and by subclasses
 protected int protectedField = 20;

 // Default (package-private) field accessible within the package
 int defaultField = 30;

 // Private field accessible only within this class
 private int privateField = 40;

 // Public constructor
 public AccessModifiers() {
     System.out.println("Public constructor called.");
 }

 // Protected method accessible within the package and by subclasses
 protected void protectedMethod() {
     System.out.println("Protected method called.");
 }

 // Default (package-private) method accessible within the package
 void defaultMethod() {
     System.out.println("Default method called.");
 }

 // Private method accessible only within this class
 private void privateMethod() {
     System.out.println("Private method called.");
 }

 // Public static method accessible from anywhere
 public static void main(String[] args) {
     AccessModifiers demo = new AccessModifiers();

     System.out.println("Public field: " + demo.publicField);
     System.out.println("Protected field: " + demo.protectedField);
     System.out.println("Default field: " + demo.defaultField);
     System.out.println("Private field: " + demo.privateField);

     demo.protectedMethod();
     demo.defaultMethod();
     demo.privateMethod();
 }
}
