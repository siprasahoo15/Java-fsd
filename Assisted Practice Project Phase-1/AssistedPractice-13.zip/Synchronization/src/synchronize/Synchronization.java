package synchronize;

class SharedResource {
    private int counter = 0;

    // Synchronized method
    public synchronized void increment() {
        counter++;
    }

    // Synchronized method
    public synchronized void decrement() {
        counter--;
    }

    // Synchronized method
    public synchronized int getValue() {
        return counter;
    }
}

class WorkerThread extends Thread {
    private SharedResource sharedResource;

    public WorkerThread(SharedResource sharedResource) {
        this.sharedResource = sharedResource;
    }

    @Override
    public void run() {
        for (int i = 0; i < 1000; i++) {
            sharedResource.increment();
            sharedResource.decrement();
        }
    }
}

public class Synchronization {
    public static void main(String[] args) {
        SharedResource sharedResource = new SharedResource();

        Thread thread1 = new WorkerThread(sharedResource);
        Thread thread2 = new WorkerThread(sharedResource);

        thread1.start();
        thread2.start();

        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Final Counter Value: " + sharedResource.getValue());
    }
}
