package list;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SortedCircularLinkedList {
    Node head;

    public SortedCircularLinkedList() {
        head = null;
    }

    // Insert a new element into the sorted circular linked list
    public void insert(int data) {
        Node newNode = new Node(data);
        
        if (head == null) {
            // If the list is empty, set the new node as the head and make it circular
            head = newNode;
            head.next = head;
        } else if (data <= head.data) {
            // If the new element is smaller than or equal to the head, insert at the beginning
            newNode.next = head;
            Node last = getLastNode();
            last.next = newNode;
            head = newNode;
        } else {
            // Find the appropriate position to insert while maintaining the sorted order
            Node current = head;
            while (current.next != head && data > current.next.data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    // Helper function to get the last node in the circular linked list
    private Node getLastNode() {
        Node current = head;
        while (current.next != head) {
            current = current.next;
        }
        return current;
    }

    // Display the sorted circular linked list
    public void display() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}

public class CircularLinkedList {
    public static void main(String[] args) {
        SortedCircularLinkedList list = new SortedCircularLinkedList();

        // Insert elements into the sorted circular linked list
        list.insert(5);
        list.insert(2);
        list.insert(9);
        list.insert(1);
        list.insert(7);

        // Display the sorted circular linked list
        list.display();
    }
}
