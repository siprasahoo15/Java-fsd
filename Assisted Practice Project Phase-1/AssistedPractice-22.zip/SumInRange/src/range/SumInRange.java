package range;

import java.util.Scanner;

public class SumInRange {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Input the number of elements in the array
        System.out.print("Enter the number of elements (n): ");
        int n = input.nextInt();

        if (n <= 0) {
            System.out.println("Invalid input. Please enter a positive integer for n.");
            return;
        }

        // Create an array of size n
        int[] arr = new int[n];

        // Input array elements
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            System.out.print("Element " + i + ": ");
            arr[i] = input.nextInt();
        }

        // Input the range [L, R]
        System.out.print("Enter the left index (L): ");
        int L = input.nextInt();
        System.out.print("Enter the right index (R): ");
        int R = input.nextInt();

        if (L < 0 || R >= n || L > R) {
            System.out.println("Invalid range. Please ensure 0 <= L <= R <= n-1.");
            return;
        }

        // Calculate the sum of elements in the range [L, R]
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }

        // Print the sum
        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);

        input.close();
    }
}
