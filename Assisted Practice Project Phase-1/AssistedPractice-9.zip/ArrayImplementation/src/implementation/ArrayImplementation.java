package implementation;

public class ArrayImplementation {

    public static void main(String[] args) {
        // Declare and initialize an array
        int[] numbers = { 1, 2, 3, 4, 5 };

        // Accessing elements of the array
        System.out.println("Element at index 2: " + numbers[2]);

        // Modifying an element
        numbers[3] = 10;
        System.out.println("Modified element at index 3: " + numbers[3]);

        // Finding the length of an array
        int length = numbers.length;
        System.out.println("Length of the array: " + length);

        // Iterating through an array
        System.out.print("Array elements: ");
        for (int i = 0; i < length; i++) {
            System.out.print(numbers[i] + " ");
        }
        System.out.println();

        // Initializing an array with a specific size
        int[] newArray = new int[3];
        System.out.println("New array length: " + newArray.length);

        // Multidimensional arrays
        int[][] matrix = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
        System.out.println("Element at (1, 2): " + matrix[1][2]);

        // Copying an array
        int[] copyOfNumbers = new int[numbers.length];
        System.arraycopy(numbers, 0, copyOfNumbers, 0, numbers.length);

        // Arrays equality check
        boolean areEqual = java.util.Arrays.equals(numbers, copyOfNumbers);
        System.out.println("Are the two arrays equal? " + areEqual);
    }
}
