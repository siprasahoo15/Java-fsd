package casting;

public class TypeCasting {
    public static void main(String[] args) {
        // Implicit Type Casting (Widening)
        int intValue = 10;
        double doubleValue = intValue; // Implicitly converts int to double
        System.out.println("Implicit Type Casting (Widening):");
        System.out.println("intValue: " + intValue);
        System.out.println("doubleValue: " + doubleValue);

        // Explicit Type Casting (Narrowing)
        double anotherDoubleValue = 15.75;
        int anotherIntValue = (int) anotherDoubleValue; // Explicitly converts double to int
        System.out.println("\nExplicit Type Casting (Narrowing):");
        System.out.println("anotherDoubleValue: " + anotherDoubleValue);
        System.out.println("anotherIntValue: " + anotherIntValue);
        
        // Explicit Type Casting with Data Loss
        double largeDoubleValue = 123456789.987654;
        int truncatedIntValue = (int) largeDoubleValue; // Explicitly converts double to int with data loss
        System.out.println("\nExplicit Type Casting with Data Loss:");
        System.out.println("largeDoubleValue: " + largeDoubleValue);
        System.out.println("truncatedIntValue: " + truncatedIntValue);
    }
}
