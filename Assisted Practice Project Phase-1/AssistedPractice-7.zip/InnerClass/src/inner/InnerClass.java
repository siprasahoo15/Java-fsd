package inner;

//Outer class
class Outer {
 private int outerField = 10;

 // Regular inner class
 class Inner {
     void display() {
         System.out.println("Inner class method: " + outerField);
     }
 }

 // Static inner class
 static class StaticInner {
     void display() {
         System.out.println("Static inner class method");
     }
 }
}

public class InnerClass{
 public static void main(String[] args) {
     // Create an instance of the outer class
     Outer outer = new Outer();

     // Create an instance of the regular inner class
     Outer.Inner inner = outer.new Inner();

     // Create an instance of the static inner class
     Outer.StaticInner staticInner = new Outer.StaticInner();

     // Access the regular inner class method
     inner.display();

     // Access the static inner class method
     staticInner.display();
 }
}
