package expressions;

import java.util.regex.*;

public class RegularExpressions {
    public static void main(String[] args) {
        // Define an array of regular expressions to test
        String[] regexPatterns = {
            "\\d+",          // Matches one or more digits
            "[A-Za-z]+",     // Matches one or more letters
            "\\w+@\\w+\\.\\w+" // Matches email addresses
        };

        // Input strings to test against the regular expressions
        String[] testStrings = {
            "12345",
            "HelloWorld",
            "test@example.com"
            // Add more test strings here
        };

        // Loop through each regular expression and test against input strings
        for (String regex : regexPatterns) {
            System.out.println("Testing regular expression: " + regex);
            Pattern pattern = Pattern.compile(regex);
            for (String input : testStrings) {
                Matcher matcher = pattern.matcher(input);
                boolean matches = matcher.matches();
                System.out.println("Input: " + input + " - Matches: " + matches);
            }
            System.out.println(); // Add a newline for better readability
        }
    }
}

