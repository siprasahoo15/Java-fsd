/**
 * 
 */
/**
 * 
 */
module RightRotateArray {
}