package array;

import java.util.Arrays;

public class RightRotateArray {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int steps = 5;

        System.out.println("Original Array: " + Arrays.toString(arr));

        // Right rotate the array by 5 steps
        rightRotateArray(arr, steps);

        System.out.println("Array after right rotation: " + Arrays.toString(arr));
    }

    public static void rightRotateArray(int[] arr, int steps) {
        int n = arr.length;

        // Ensure steps is within the range of array size
        steps = steps % n;

        // Create a temporary array to store the rotated elements
        int[] temp = new int[n];

        // Copy the last 'steps' elements to the temporary array
        for (int i = 0; i < steps; i++) {
            temp[i] = arr[n - steps + i];
        }

        // Shift the remaining elements to the right
        for (int i = n - steps - 1; i >= 0; i--) {
            arr[i + steps] = arr[i];
        }

        // Copy the elements from the temporary array back to the original array
        for (int i = 0; i < steps; i++) {
            arr[i] = temp[i];
        }
    }
}
