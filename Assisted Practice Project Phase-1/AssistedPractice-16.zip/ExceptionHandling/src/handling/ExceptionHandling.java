package handling;

import java.util.Scanner;

//Custom exception class for handling division by zero
class DivisionByZeroException extends Exception {
 public DivisionByZeroException(String message) {
     super(message);
 }
}

public class ExceptionHandling{
 public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);

     try {
         System.out.print("Enter the numerator: ");
         int numerator = scanner.nextInt();

         System.out.print("Enter the denominator: ");
         int denominator = scanner.nextInt();

         // Check for division by zero and throw a custom exception if necessary
         if (denominator == 0) {
             throw new DivisionByZeroException("Division by zero is not allowed.");
         }

         int quotient = divide(numerator, denominator);
         System.out.println("Quotient: " + quotient);
     } catch (DivisionByZeroException e) {
         System.out.println("Error: " + e.getMessage());
     } catch (java.util.InputMismatchException e) {
         System.out.println("Error: Invalid input. Please enter valid integers.");
     } finally {
         scanner.close();
         System.out.println("Finally block executed.");
     }
 }

 // Method to perform division and throw an exception if division by zero occurs
 public static int divide(int numerator, int denominator) throws DivisionByZeroException {
     if (denominator == 0) {
         throw new DivisionByZeroException("Division by zero is not allowed.");
     }
     return numerator / denominator;
 }
}
