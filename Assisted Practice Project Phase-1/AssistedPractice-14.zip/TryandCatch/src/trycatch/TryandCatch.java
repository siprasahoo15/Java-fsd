package trycatch;

public class TryandCatch {
    public static void main(String[] args) {
        try {
            // Code that may throw an exception
            int result = divide(10, 0);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            // Catch the exception and handle it
            System.out.println("An error occurred: " + e.getMessage());
        }
    }

    // A method that divides two numbers but may throw an exception
    public static int divide(int dividend, int divisor) {
        return dividend / divisor;
    }
}
