package element;

import java.util.Random;

public class FourthSmallestElement {

    public static int findFourthSmallest(int[] arr) {
        if (arr == null || arr.length < 4) {
            throw new IllegalArgumentException("Input array must have at least four elements.");
        }

        return quickSelect(arr, 0, arr.length - 1, 4);
    }

    private static int quickSelect(int[] arr, int left, int right, int k) {
        if (left == right) {
            return arr[left];
        }

        int pivotIndex = partition(arr, left, right);

        if (k == pivotIndex - left + 1) {
            return arr[pivotIndex];
        } else if (k < pivotIndex - left + 1) {
            return quickSelect(arr, left, pivotIndex - 1, k);
        } else {
            return quickSelect(arr, pivotIndex + 1, right, k - (pivotIndex - left + 1));
        }
    }

    private static int partition(int[] arr, int left, int right) {
        int randomIndex = new Random().nextInt(right - left + 1) + left;
        swap(arr, randomIndex, right);

        int pivot = arr[right];
        int i = left - 1;

        for (int j = left; j < right; j++) {
            if (arr[j] < pivot) {
                i++;
                swap(arr, i, j);
            }
        }

        swap(arr, i + 1, right);

        return i + 1;
    }

    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    public static void main(String[] args) {
        int[] arr = {12, 3, 1, 15, 7, 5, 10, 4};
        int fourthSmallest = findFourthSmallest(arr);
        System.out.println("The fourth smallest element is: " + fourthSmallest);
    }
}
