package java;

//Define a class called "Person" with attributes and methods
class Person {
 // Attributes
 private String name;
 private int age;

 // Constructor
 public Person(String name, int age) {
     this.name = name;
     this.age = age;
 }

 // Encapsulation: Getters and Setters
 public String getName() {
     return name;
 }

 public void setName(String name) {
     this.name = name;
 }

 public int getAge() {
     return age;
 }

 public void setAge(int age) {
     if (age > 0) {
         this.age = age;
     }
 }

 // Abstraction: Display person's information
 public void displayInfo() {
     System.out.println("Name: " + name);
     System.out.println("Age: " + age);
 }
}

//Inheritance: Create a subclass "Student" that inherits from "Person"
class Student extends Person {
 private int studentId;

 public Student(String name, int age, int studentId) {
     super(name, age);
     this.studentId = studentId;
 }

 public int getStudentId() {
     return studentId;
 }

 public void setStudentId(int studentId) {
     this.studentId = studentId;
 }

 @Override
 public void displayInfo() {
     super.displayInfo(); // Call the parent class's displayInfo method
     System.out.println("Student ID: " + studentId);
 }
}

public class JavaPillars {
 public static void main(String[] args) {
     // Create objects of the Person and Student classes
     Person person = new Person("John", 30);
     Student student = new Student("Alice", 20, 12345);

     // Using objects and demonstrating encapsulation
     System.out.println("Person's Name: " + person.getName());
     System.out.println("Student's Name: " + student.getName());

     System.out.println("Person's Information:");
     person.displayInfo();

     System.out.println("Student's Information:");
     student.displayInfo();
 }
}
