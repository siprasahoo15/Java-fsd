package method;

public class MethodImplementation {
    // Method to verify
    public static int add(int a, int b) {
        return a + b;
    }

    // Another method to verify
    public static String concatenateStrings(String str1, String str2) {
        return str1 + str2;
    }

    // Main method to call and verify the methods
    public static void main(String[] args) {
        // Verify the add method
        int sum = add(5, 3);
        System.out.println("Sum: " + sum);
        if (sum == 8) {
            System.out.println("add method verified successfully.");
        } else {
            System.out.println("add method verification failed.");
        }

        // Verify the concatenateStrings method
        String result = concatenateStrings("Hello, ", "World!");
        System.out.println("Concatenation: " + result);
        if ("Hello, World!".equals(result)) {
            System.out.println("concatenateStrings method verified successfully.");
        } else {
            System.out.println("concatenateStrings method verification failed.");
        }
    }
}
