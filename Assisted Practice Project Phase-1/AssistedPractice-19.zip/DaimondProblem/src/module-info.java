/**
 * 
 */
/**
 * 
 */
module DaimondProblem {
}