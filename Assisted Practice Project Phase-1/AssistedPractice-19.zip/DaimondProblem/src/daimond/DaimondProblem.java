package daimond;

interface Animal {
    void eat();
}

interface Bird extends Animal {
    void fly();
}

interface Mammal extends Animal {
    void run();
}

// Create a class that implements both Bird and Mammal interfaces
class Bat implements Bird, Mammal {
    @Override
    public void eat() {
        System.out.println("Bat is eating.");
    }

    @Override
    public void fly() {
        System.out.println("Bat is flying.");
    }

    @Override
    public void run() {
        System.out.println("Bat is running.");
    }
}

public class DaimondProblem {
    public static void main(String[] args) {
        Bat bat = new Bat();
        
        // Call methods from both Bird and Mammal interfaces
        bat.eat();
        bat.fly();
        bat.run();
    }
}
