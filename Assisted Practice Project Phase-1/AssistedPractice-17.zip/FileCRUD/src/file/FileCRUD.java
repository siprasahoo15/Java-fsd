package file;

import java.io.*;

public class FileCRUD{
    public static void main(String[] args) {
        String fileName = "example.txt";

        // Create a new file
        createFile(fileName);

        // Read and display the file contents
        readFile(fileName);

        // Update the file
        updateFile(fileName, "This is the updated content.");

        // Read and display the updated file contents
        readFile(fileName);

        // Delete the file
        deleteFile(fileName);
    }

    // Create a new file
    public static void createFile(String fileName) {
        try {
            FileWriter writer = new FileWriter(fileName);
            writer.write("Hello, World!");
            writer.close();
            System.out.println("File created successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Read and display file contents
    public static void readFile(String fileName) {
        try {
            FileReader reader = new FileReader(fileName);
            int character;
            StringBuilder content = new StringBuilder();

            while ((character = reader.read()) != -1) {
                content.append((char) character);
            }

            reader.close();
            System.out.println("File content:");
            System.out.println(content.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Update the file
    public static void updateFile(String fileName, String newContent) {
        try {
            FileWriter writer = new FileWriter(fileName);
            writer.write(newContent);
            writer.close();
            System.out.println("File updated successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Delete the file
    public static void deleteFile(String fileName) {
        File file = new File(fileName);
        if (file.delete()) {
            System.out.println("File deleted successfully.");
        } else {
            System.out.println("Failed to delete the file.");
        }
    }
}
